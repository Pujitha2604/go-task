package main
 
import (
    "context"
    "fmt"
 
    "github.com/aws/aws-lambda-go/lambda"
    "github.com/aws/aws-sdk-go-v2/config"
)
 
// ECRPushEvent represents the structure of an ECR push event payload
type ECRPushEvent struct {
    Detail struct {
        RepositoryName string   `json:"repo-go"`
        ImageTags      []string `json:"image-tags"`
    } `json:"detail"`
}
 
func handler(ctx context.Context, event ECRPushEvent) error {
    _, err := config.LoadDefaultConfig(ctx)
    if err != nil {
        return fmt.Errorf("failed to load AWS SDK config: %v", err)
    }
 
    // Retrieve the latest image tag from ECR event payload
    repoName := event.Detail.RepositoryName
    imageTags := event.Detail.ImageTags
    if len(imageTags) == 0 {
        return fmt.Errorf("no image tags found in the ECR push event")
    }
    latestTag := imageTags[len(imageTags)-1] // Assuming the latest tag is the last one in the list
 
    // Perform any further processing with the latest image tag
    fmt.Printf("Latest image tag for repository '%s': %s\n", repoName, latestTag)
 
    // Example: Use the latest tag to pull the image or perform other operations
 
    return nil
}
 
func main() {
    lambda.Start(handler)
}